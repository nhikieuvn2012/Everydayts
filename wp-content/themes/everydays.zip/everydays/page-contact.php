<?php
/**
 * Template Name: Contact
 * 
 * */
get_header();
?>
<!-- ===========Services Wrap Start========== --> 

<div class="services-section" style="background-color:ghostwhite;-webkit-border-bottom-right-radius: 5px;
-webkit-border-bottom-left-radius: 5px;
-moz-border-radius-bottomright: 5px;
-moz-border-radius-bottomleft: 5px;
border-bottom-right-radius: 5px;
border-bottom-left-radius: 5px;padding-top: 10px;">
<p>            <?php
            echo apply_filters( 'the_content',$post->post_content);
            ?></p>
<br clear="all" /> 

</div> 


<?php
get_footer();
?>