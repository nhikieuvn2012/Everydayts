<!-- ===========Service Area Wrap Start========== -->

<div class="service-area">

<h4>Service Area</h4>
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15954.987717767066!2d103.703071!3d1.3278370000000033!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31da0ff9816f3eb9%3A0xbf94f07333888cc!2sIdeaverse+Network+Pte.+Ltd.!5e0!3m2!1sen!2s!4v1407122316262" width="453" height="318" frameborder="0" style="border:solid 6px #E0E0E0;"></iframe>
<div class="contact-area">

<h3>Everyday Cleaning Services</h3>

<p>10 Anson Road #26-04 International Plaza Singapore 079903<br />

<span><a href="tel:+65 6650 8815">office: +65 6650 8815</a></span></p>
<h5>Office Hours:</h5>
<p>Monday - Thursday: 8:00am - 6:00pm<br />
Friday: 8:00am - 4:00pm</p>

<h5>Services Hours:</h5>
<p>Monday - Friday: 7:00am - 7:00pm<br />
Saturday: 7:00am - 2:00pm </p>
</div><br clear="all" /></div>
<!-- ===========Service Area Wrap End========== -->
<!-- ===========Footer Area Wrap Start========== -->
<p id="back-top"><a href="#top">Top</a></p>



<div class="footer-main-section">

<div class="footer-menu">

                   <?php
                    $menu_name = 'menu-footer';
                    if(($locations=get_nav_menu_locations())&&isset( $locations[ $menu_name ] ) ) {
                        $menu = wp_get_nav_menu_object( $locations[ $menu_name ] );
                                        
                        $menu_items = wp_get_nav_menu_items($menu->term_id);
                        
                                     
                        $menu_list = '<ul>';
                        foreach ( (array) $menu_items as $key => $menu_item ) {
                            if($menu_item->menu_item_parent==0){
                               
                                $count=0;
                                foreach ( (array) $menu_items as $key => $menu_item_p ) {
                                    if($menu_item_p->menu_item_parent==$menu_item->ID){
                                      $count=1;
                                    }
                                }
                                
                                $menu_list .= '<li><a title="'.$menu_item->title.'" href="'.$menu_item->url.'">'.$menu_item->title.'</a>';
                                    if($count==1){
                                        $menu_list.='<ul>';
                                                foreach ( (array) $menu_items as $key => $menu_item_p ) {
                                                    if($menu_item_p->menu_item_parent==$menu_item->ID){
                                                        
                                                        $count2=0;
                                                        foreach ( (array) $menu_items as $key => $menu_item_p2){
                                                        if($menu_item_p2->menu_item_parent==$menu_item_p->ID){
                                                            $count2=1;
                                                        }
                                                        }
                                                        
                                                       $menu_list.= '<li><a href="' .$menu_item_p->url. '">'.$menu_item_p->title.'</a>';
                                                       
                                                        if($count2==1){
                                                            $menu_list.='<ul>';
                                                            foreach ( (array) $menu_items as $key => $menu_item_p2){
                                                                if($menu_item_p2->menu_item_parent==$menu_item_p->ID){
                                                                    $menu_list .= '<li ><a href="'.$menu_item_p2->url.'">'.$menu_item_p2->title.'</a></li>';  
                                                                }
                                                            }
                                                            $menu_list.='</ul>';
                                                        }
                                                       $menu_list.='</li>';
                                                    }
                                                }
                                        $menu_list.='</ul>';
                                    }
                                $menu_list.='</li>';
                            }
                        }
                                        
                        $menu_list .= '</ul>';
                    
                     }
                     echo $menu_list;
                    ?>


</div>
<div class="copy-right">
© 2014. Everyday Total Solutions. All right reserved.
<br />
</div> 
</div>

<!-- ===========Footer Start Wrap End========== --> 

<!-- AdLuge Visitor Tracker Starts Here. Updated on April 2013 -->

<script type="text/javascript">

var AdLBaseURL = (("https:" == document.location.protocol) ? "https://www.adluge.com/trackerjs/" : 



"http://www.adluge.com/trackerjs/");

document.write(unescape("%3Cscript src='" + AdLBaseURL + "visitors-tracker.js' type='text/javascript'%3E%3C/script%3E"));

</script>

<!-- AdLuge Visitor Tracker Ends Here -->  

<!-- start number replacer -->

<script type="text/javascript"><!--

vs_account_id      = "CtjSZlJNw6sdsQD_";

//--></script>

<script type="text/javascript" src="../leads.adluge.com/euinc/number-changer.js">

</script>

<!-- end ad widget -->


<!--<script>
$( window ).load(function() {
var asd=$('.vsctcnumber:first').text();
//$('.phone span > a').attr('onclick',"goog_report_conversion('tel:"+asd+"')")
$('.phone span > a').attr('href',"tel:"+asd);
});
</script>-->
<!-- Visitor Tracking Code Starts Here -->                
<script type="text/javascript">                
 var adlBaseURL ="http://track.adluge.com/";               
  document.write(unescape("%3Cscript src='" + adlBaseURL + "javascripts/tracker.js' type='text/javascript'%3E%3C/script%3E"));                
    </script>                
        <script type="text/javascript">        
  try {                
  var adlTracker = Adl.getTracker(adlBaseURL + 't/', 'AL_84' );                
  adlTracker.trackPageView();                
   adlTracker.enableLinkTracking();                
  }                
  catch( err ) {}                
  </script>                
<!-- Visitor Tracking Code Ends Here -->

<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 977812188;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="../www.googleadservices.com/pagead/f.txt">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="http://googleads.g.doubleclick.net/pagead/viewthroughconversion/977812188/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
</body>


<!-- Mirrored from www.sunrise-cleaning.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 30 Jul 2014 03:28:17 GMT -->
</html>

<script type="text/javascript">

//--------------------------------- Save Captcha Function-------------------//

function save_captcha(obj,arg)

{

_link=document.links;



for(i=0;i<_link.length;i++)

{

	if(_link[i].className=="captcha-image") {	

		if(_link[i]!=obj) {

			_link[i].childNodes[0].style.border='1px solid #f3f3f3';

		} else {

			_link[i].childNodes[0].style.border='1px solid #000';

		}

	}

}

document.getElementById("captcha_hid").value=arg;

}

//--------------------------------- Save Captcha Function-------------------//

//--------------------------------- Captcha Validation-------------------//

 function validateForm(thisform)

 {

    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

 

	jQuery('#submit_form').hide();

	jQuery('#wait_con').show();

	

	if(jQuery.trim(jQuery('#fname').val())=='' || jQuery.trim(jQuery('#fname').val())=='Name*')

	{

		alert("Please enter your Name.");

		jQuery('#submit_form').show();

		jQuery('#wait_con').hide();

		jQuery('#fname').focus();

		return false;

	}	

	

	 

	if(jQuery.trim(jQuery('#femail').val())=='' || jQuery.trim(jQuery('#femail').val())=='Email*')

	{

		alert("Please enter your Email Address.");

		jQuery('#submit_form').show();jQuery('#wait_con').hide();

		jQuery('#femail').focus();

		return false;

	}	

		

	if(jQuery.trim(jQuery('#femail').val())!='' && !emailReg.test(jQuery.trim(jQuery('#femail').val()))) 

	{

		 alert("Sorry, you have entered an invalid Email Address.");

		 jQuery('#submit_form').show();jQuery('#wait_con').hide();

		 jQuery('#femail').select();

		 jQuery('#femail').focus();

		 return false;	 

	}

	if(jQuery.trim(jQuery('#fphone').val())=='' || jQuery.trim(jQuery('#fphone').val())=='PHONE*')

	{

		alert("Please enter your Phone Number.");

		jQuery('#submit_form').show();jQuery('#wait_con').hide();

		jQuery('#fphone').focus();

		return false;

	}

	/*if(jQuery.trim(jQuery('#fcomments').val())=='' ||  jQuery.trim(jQuery('#fcomments').val())=='Questions/Comments*')

	{

		alert("Please enter your Questions/Comments.");

		  jQuery('#submit_form').show();jQuery('#wait_con').hide();

		jQuery('#fcomments').focus();

		return false;

	}*/

 

    if(jQuery.trim(jQuery('#captcha_hid').val())=='')

    	{

		  alert("The shape you selected is incorrect, please select the right one.");

		  jQuery('#submit_form').show();jQuery('#wait_con').hide();

		  jQuery('#captcha_hid').select();

		  jQuery('#captcha_hid').focus();

		  return false;

	   }

   	validateCaptcha('wp-content/themes/sunrise-cleaning-services/verify_captcha.html');

	return false;

}

//--------------------------------- Captcha Validation -------------------//

//--------------------------------- Captcha Refresh -------------------//

function refreshCapcha(arg2)

{

jQuery("#captcha_div_con").load('wp-content/themes/sunrise-cleaning-services/captcha_code681a.html?id=1');

}

//--------------------------------- Captcha Refresh -------------------//

//--------------------------------- Captcha Validation -------------------//

function validateCaptcha(argUrl)

{

	var url=argUrl;

	var captchavalue=document.requestfrm.captcha_hid.value;



$.ajax({

				type: "GET",

				url: url,

				data: "captchaVal="+captchavalue,

				success: function(data){

				//alert(data);

				 if(data=="yes")

				 {

				  document.requestfrm.submit();

				 }

				 else

				 {

				   alert("Incorrect answer, please select the right shape.");

				   document.getElementById('submit_form').style.display ='';

				   document.getElementById('wait_con').style.display ='none';

		 		   refreshCapcha();

				   return false;

				 }

					

			}

	  });

}

//--------------------------------- Captcha Validation -------------------//

</script>